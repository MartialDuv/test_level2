package com.example.mduve.test_runtastic;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    Button btnHit;
    TextView txtJson;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHit = (Button) findViewById(R.id.btnHit);
        txtJson = (TextView) findViewById(R.id.tvJsonItem);
        txtJson.setMovementMethod(new ScrollingMovementMethod());

        btnHit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Information information = new Information();
                information.execute();


                String result = null;
                try {
                    result = information.get();

                    JSONObject resultInJSON = new JSONObject(result);
                    JSONArray groups = resultInJSON.getJSONArray("groups");
                    List<JSONArray> members = new ArrayList<JSONArray>();
                    JSONArray membersAsArray;

                    result = "";
                    for (int i=0; i < groups.length(); i++)
                    {
                        try {
                            JSONObject group = groups.getJSONObject(i);
                            members.add(group.getJSONArray("members"));
                        } catch (JSONException e) {
                            // Oops
                        }
                    }

                    int cpt = 0;
                    for (JSONArray each : members)
                    {
                        result += "Group " + cpt + " : ";
                        ArrayList<Double> paces = new ArrayList<Double>();
                        ArrayList<Double> fastestGroup = new ArrayList<Double>();
                        for (int i=0; i < each.length(); i++)
                        {
                            try {
                                JSONObject member = each.getJSONObject(i);
                                Double pace = member.getDouble("member_active_minutes")
                                        / member.getDouble("member_distance_covered");
                                paces.add(pace);
                                result += member.getString("member_first_name") + " " +
                                        member.getString("member_last_name") + " " + pace
                                        + ", ";

                            } catch (JSONException e) {

                            }
                        }
                        result += "\nFastest group " + cpt + " : ";
                        Double max;
                        boolean flag = false;
                        while(flag != true) {
                            max = 0.0;
                            for(Double d : paces) {
                                if(d > max) {
                                    max = d;
                                }
                            }
                            paces.remove(max);
                            for(Double d : paces) {
                                if(Math.abs(d - max) <= 1) {
                                    fastestGroup.add(d);
                                }
                            }
                            if(!fastestGroup.isEmpty()) {
                                fastestGroup.add(max);
                                flag = true;
                            }
                            if(paces.isEmpty() && fastestGroup.isEmpty()) {
                                flag=true;
                            }
                        }
                        if(fastestGroup.isEmpty()) {
                            result += "no training buddies\n";
                        }
                        else {
                            result += fastestGroup.toString()+ "\n";
                        }

                        result += "\n";
                        cpt++;
                    }


                    txtJson.setText(result);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });


    }

}